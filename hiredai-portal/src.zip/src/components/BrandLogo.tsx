type BrandLogoProps = {
  className?: string
}

export default function BrandLogo({ className = '' }: BrandLogoProps) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12 2.5L21.5 12L12 21.5L2.5 12L12 2.5Z"
        className="fill-current"
      />
      <path
        d="M12 7.25L16.75 12L12 16.75L7.25 12L12 7.25Z"
        fill="white"
        fillOpacity="0.35"
      />
    </svg>
  )
}

export { BrandLogo }
