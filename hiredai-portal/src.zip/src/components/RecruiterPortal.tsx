import { useMemo, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  Activity,
  ArrowRight,
  Bell,
  Briefcase,
  Building2,
  CalendarDays,
  ChevronDown, 
  ChevronRight,
  CircleCheckBig,
  Clock3,
  Filter,
  FileText,
  Globe,
  LayoutDashboard,
  LogOut,
  Mail,
  MapPin,
  Menu,
  MessageSquareMore,
  MoreHorizontal,
  MoveRight,
  PencilLine,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  TrendingUp,
  Users,
  Workflow,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { setPortalRole } from "../auth/portalRole";
import BrandLogo from "./BrandLogo";
import UserAvatar from "./UserAvatar";
import TopNavBar from "./TopNavBar";

export type RecruiterPortalPage =
  | "home"
  | "dashboard"
  | "post-job"
  | "jobs"
  | "applications"
  | "company"
  | "settings"
  | "interviews"
  | "shortlisted";

type ApplicationStatus = "Applied" | "Reviewed" | "Shortlisted" | "Interview" | "Rejected" | "Hired";

interface RecruiterPortalProps {
  page: RecruiterPortalPage;
}

interface SidebarItem {
  id: RecruiterPortalPage;
  label: string;
  icon: typeof LayoutDashboard;
  path: string;
}

interface JobRow {
  id: string;
  title: string;
  department: string;
  status: "Active" | "Paused" | "Closed" | "Draft";
  applications: number;
  atsAvg: number;
  location: string;
  posted: string;
}

interface ApplicationRow {
  id: string;
  candidate: string;
  role: string;
  score: number;
  experience: string;
  skillsMatch: string;
  appliedDate: string;
  location: string;
  education: string;
  status: ApplicationStatus;
}

interface InterviewRow {
  candidate: string;
  role: string;
  time: string;
  type: string;
  status: "Scheduled" | "Live" | "Completed";
}

const NAV_ITEMS: SidebarItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, path: "/hr/dashboard" },
  { id: "post-job", label: "Post Job", icon: Plus, path: "/hr/post-job" },
  { id: "jobs", label: "My Jobs", icon: Briefcase, path: "/hr/jobs" },
  { id: "applications", label: "Applications", icon: FileText, path: "/hr/applications" },
  { id: "shortlisted", label: "Shortlisted", icon: Star, path: "/hr/shortlisted" },
  { id: "interviews", label: "Interviews", icon: CalendarDays, path: "/hr/interviews" },
  { id: "company", label: "Company Profile", icon: Building2, path: "/hr/company" },
  { id: "settings", label: "Settings", icon: Settings, path: "/hr/settings" },
];

const STATS = [
  { label: "Active Jobs", value: "28", delta: "+4 this month", icon: Briefcase, tone: "from-violet-500 to-fuchsia-500" },
  { label: "Applications", value: "1,284", delta: "+18% week over week", icon: FileText, tone: "from-cyan-500 to-sky-500" },
  { label: "Interviews", value: "46", delta: "11 this week", icon: CalendarDays, tone: "from-emerald-500 to-teal-500" },
  { label: "Hired", value: "17", delta: "3 in the last 7 days", icon: CircleCheckBig, tone: "from-amber-500 to-orange-500" },
];

const DASHBOARD_STATS = [
  { label: "Active Jobs", value: "28", delta: "+4 this month", icon: Briefcase, tone: "from-violet-500 to-fuchsia-500" },
  { label: "Applications", value: "1,284", delta: "+18% over week", icon: FileText, tone: "from-sky-500 to-blue-500" },
  { label: "Interviews", value: "46", delta: "+11 this week", icon: CalendarDays, tone: "from-orange-500 to-amber-500" },
  { label: "Hired", value: "17", delta: "+3 in the last 7 days", icon: CircleCheckBig, tone: "from-emerald-500 to-green-500" },
];

const DASHBOARD_TREND_DATA = [
  { name: "May 2", applications: 118 },
  { name: "May 3", applications: 146 },
  { name: "May 4", applications: 192 },
  { name: "May 5", applications: 222 },
  { name: "May 6", applications: 296 },
  { name: "May 7", applications: 238 },
  { name: "May 8", applications: 176 },
];

const DASHBOARD_ACTIVITY = [
  {
    icon: FileText,
    title: "82 applications screened",
    subtitle: "Senior Product Designer posted 3 days ago",
    tone: "bg-violet-50 text-violet-600",
  },
  {
    icon: Target,
    title: "94 ATS average",
    subtitle: "Data Scientist role pulled strongest fit scores",
    tone: "bg-sky-50 text-sky-600",
  },
  {
    icon: Workflow,
    title: "6-stage pipeline active",
    subtitle: "Interview round moving into shortlist review",
    tone: "bg-emerald-50 text-emerald-600",
  },
];

const DASHBOARD_PIPELINE = [
  { stage: "Applied", count: 1, candidate: "Maya Chen", role: "Product Designer" },
  { stage: "Reviewed", count: 1, candidate: "Rahul Verma", role: "DevOps Engineer" },
  { stage: "Shortlisted", count: 1, candidate: "Aarav Mehta", role: "Data Scientist" },
  { stage: "Interview", count: 1, candidate: "Priya Shah", role: "Backend Engineer" },
  { stage: "Offer", count: 0, candidate: "No candidates yet", role: "" },
  { stage: "Hired", count: 1, candidate: "Sneha Iyer", role: "HR Business Partner" },
];

const DASHBOARD_APPLICATIONS = [
  { id: "A-001", initials: "AM", candidate: "Aarav Mehta", role: "Data Scientist", ats: 94, experience: "4 years", applied: "Aug 5, 2025", status: "Shortlisted" as ApplicationStatus },
  { id: "A-002", initials: "PS", candidate: "Priya Shah", role: "Backend Engineer", ats: 88, experience: "5 years", applied: "Aug 5, 2025", status: "Interview" as ApplicationStatus },
  { id: "A-003", initials: "MC", candidate: "Maya Chen", role: "Product Designer", ats: 96, experience: "6 years", applied: "Aug 4, 2025", status: "Applied" as ApplicationStatus },
  { id: "A-004", initials: "RV", candidate: "Rahul Verma", role: "DevOps Engineer", ats: 71, experience: "3 years", applied: "Aug 4, 2025", status: "Reviewed" as ApplicationStatus },
];

const TREND_DATA = [
  { name: "Mon", applications: 42, interviews: 7, hires: 1 },
  { name: "Tue", applications: 55, interviews: 10, hires: 2 },
  { name: "Wed", applications: 63, interviews: 12, hires: 2 },
  { name: "Thu", applications: 50, interviews: 9, hires: 1 },
  { name: "Fri", applications: 74, interviews: 14, hires: 3 },
  { name: "Sat", applications: 45, interviews: 8, hires: 1 },
  { name: "Sun", applications: 38, interviews: 6, hires: 1 },
];

const PIPELINE_DATA = [
  { name: "Applied", value: 478, color: "#8B5CF6" },
  { name: "Reviewed", value: 186, color: "#06B6D4" },
  { name: "Shortlisted", value: 102, color: "#10B981" },
  { name: "Interview", value: 34, color: "#F59E0B" },
  { name: "Offer", value: 14, color: "#EF4444" },
  { name: "Hired", value: 17, color: "#6366F1" },
];

export const NOTIFICATIONS = [
  { title: "New application received", text: "Maya Chen applied for Senior Product Designer.", time: "2 min ago", unread: true },
  { title: "Interview reminder", text: "3 interviews start in the next 45 minutes.", time: "15 min ago", unread: true },
  { title: "Job expiring soon", text: "Backend Engineer role closes tomorrow at 5:00 PM.", time: "1 hr ago", unread: false },
  { title: "Hiring completed", text: "Cloud Security Analyst role has been filled.", time: "4 hr ago", unread: false },
];

const JOBS: JobRow[] = [
  { id: "J-1024", title: "Senior Product Designer", department: "Design", status: "Active", applications: 82, atsAvg: 84, location: "Remote", posted: "3 days ago" },
  { id: "J-1032", title: "Backend Engineer", department: "Engineering", status: "Paused", applications: 141, atsAvg: 77, location: "Bengaluru", posted: "8 days ago" },
  { id: "J-1038", title: "Data Scientist", department: "Data Science", status: "Active", applications: 66, atsAvg: 88, location: "Hybrid", posted: "2 days ago" },
  { id: "J-1041", title: "HR Business Partner", department: "People", status: "Draft", applications: 0, atsAvg: 0, location: "Mumbai", posted: "Draft" },
  { id: "J-1044", title: "DevOps Engineer", department: "Cloud", status: "Closed", applications: 97, atsAvg: 79, location: "Remote", posted: "18 days ago" },
];

const APPLICATIONS: ApplicationRow[] = [
  { id: "A-001", candidate: "Aarav Mehta", role: "Data Scientist", score: 94, experience: "4 years", skillsMatch: "91%", appliedDate: "Aug 5", location: "Bengaluru", education: "M.Tech", status: "Shortlisted" },
  { id: "A-002", candidate: "Priya Shah", role: "Backend Engineer", score: 88, experience: "5 years", skillsMatch: "86%", appliedDate: "Aug 5", location: "Pune", education: "B.E.", status: "Interview" },
  { id: "A-003", candidate: "Maya Chen", role: "Product Designer", score: 96, experience: "6 years", skillsMatch: "93%", appliedDate: "Aug 4", location: "Remote", education: "B.Des", status: "Applied" },
  { id: "A-004", candidate: "Rahul Verma", role: "DevOps Engineer", score: 71, experience: "3 years", skillsMatch: "69%", appliedDate: "Aug 4", location: "Hyderabad", education: "B.Tech", status: "Reviewed" },
  { id: "A-005", candidate: "Sneha Iyer", role: "HR Business Partner", score: 84, experience: "8 years", skillsMatch: "83%", appliedDate: "Aug 3", location: "Chennai", education: "MBA", status: "Hired" },
];

const INTERVIEWS: InterviewRow[] = [
  { candidate: "Maya Chen", role: "Product Designer", time: "10:00 AM", type: "Google Meet", status: "Live" },
  { candidate: "Priya Shah", role: "Backend Engineer", time: "11:30 AM", type: "Zoom", status: "Scheduled" },
  { candidate: "Aarav Mehta", role: "Data Scientist", time: "02:00 PM", type: "In person", status: "Scheduled" },
];

const PIPELINE_COLUMNS: { title: ApplicationStatus | "Offer"; items: ApplicationRow[] }[] = [
  { title: "Applied", items: APPLICATIONS.filter((app) => app.status === "Applied") },
  { title: "Reviewed", items: APPLICATIONS.filter((app) => app.status === "Reviewed") },
  { title: "Shortlisted", items: APPLICATIONS.filter((app) => app.status === "Shortlisted") },
  { title: "Interview", items: APPLICATIONS.filter((app) => app.status === "Interview") },
  { title: "Offer", items: [] },
  { title: "Hired", items: APPLICATIONS.filter((app) => app.status === "Hired") },
];

function currency(value: number) {
  return new Intl.NumberFormat("en-IN").format(value);
}

function statusTone(status: string) {
  switch (status) {
    case "Active":
      return "bg-emerald-50 text-emerald-700 border-emerald-200";
    case "Paused":
      return "bg-amber-50 text-amber-700 border-amber-200";
    case "Closed":
      return "bg-slate-100 text-slate-600 border-slate-200";
    default:
      return "bg-violet-50 text-violet-700 border-violet-200";
  }
}

function applicationTone(status: ApplicationStatus) {
  switch (status) {
    case "Applied":
      return "bg-slate-100 text-slate-700";
    case "Reviewed":
      return "bg-cyan-50 text-cyan-700";
    case "Shortlisted":
      return "bg-violet-50 text-violet-700";
    case "Interview":
      return "bg-amber-50 text-amber-700";
    case "Rejected":
      return "bg-red-50 text-red-700";
    case "Hired":
      return "bg-emerald-50 text-emerald-700";
  }
}

function statusDot(status: InterviewRow["status"]) {
  switch (status) {
    case "Live":
      return "bg-emerald-500";
    case "Scheduled":
      return "bg-violet-500";
    case "Completed":
      return "bg-slate-400";
  }
}

function pageTitle(page: RecruiterPortalPage) {
  switch (page) {
    case "home":
      return "Home";
    case "dashboard":
      return "Hiring dashboard";
    case "post-job":
      return "Post Job";
    case "jobs":
      return "My Jobs";
    case "applications":
      return "Applications";
    case "company":
      return "Company Profile";
    case "settings":
      return "Settings";
    case "interviews":
      return "Interviews";
    case "shortlisted":
      return "Shortlisted";
  }
}

export function GlassPanel({
  title,
  subtitle,
  action,
  children,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="rounded-[28px] border border-white/70 bg-white/80 p-5 shadow-[0_24px_64px_rgba(124,58,237,0.10)] backdrop-blur-2xl md:p-6">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-slate-950">{title}</h2>
          {subtitle ? <p className="mt-1 text-sm leading-6 text-slate-500">{subtitle}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function MetricCard({
  label,
  value,
  delta,
  icon: Icon,
  tone,
  index = 0,
}: {
  label: string;
  value: string;
  delta: string;
  icon: typeof Briefcase;
  tone: string;
  index?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay: index * 0.08, ease: "easeOut" }}
      whileHover={{ y: -4 }}
      className="rounded-[26px] border border-white/70 bg-white/80 p-5 shadow-[0_18px_48px_rgba(124,58,237,0.10)] backdrop-blur-2xl transition-shadow hover:shadow-[0_24px_60px_rgba(124,58,237,0.18)]"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-medium text-slate-500">{label}</div>
          <div className="mt-2 text-3xl font-extrabold tracking-tight text-slate-950">{value}</div>
          <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">
            <TrendingUp size={13} />
            {delta}
          </div>
        </div>
        <motion.div
          initial={{ scale: 0, rotate: -20 }}
          whileInView={{ scale: 1, rotate: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: index * 0.08 + 0.15, type: "spring", stiffness: 220 }}
          className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${tone} text-white shadow-[0_12px_30px_rgba(124,58,237,0.25)]`}
        >
          <Icon size={20} />
        </motion.div>
      </div>
    </motion.div>
  );
}


export function MobileDrawer({
  open,
  currentPage,
  onClose,
  onNavigate,
  onLogout,
}: {
  open: boolean;
  currentPage: RecruiterPortalPage;
  onClose: () => void;
  onNavigate: (path: string) => void;
  onLogout: () => void;
}) {
  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-50 lg:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18, ease: "easeOut" }}
          onMouseDown={onClose}
        >
          <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" />
          <motion.aside
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ duration: 0.24, ease: "easeInOut" }}
            onMouseDown={(event) => event.stopPropagation()}
            className="relative flex h-full w-[86vw] max-w-[300px] flex-col border-r border-violet-100 bg-white/95 shadow-[24px_0_60px_rgba(15,23,42,0.16)] backdrop-blur-2xl"
          >
            <div className="flex items-center justify-between border-b border-violet-100 px-5 py-5">
              <div className="flex items-center gap-3">
                <BrandLogo size={36} />
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.24em] text-violet-500">Recruiter Portal</div>
                  <div className="font-bold tracking-tight text-slate-950">HiredAI HR</div>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700"
              >
                <Menu size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              <nav className="space-y-1">
                {NAV_ITEMS.map((item) => {
                  const active = currentPage === item.id;
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onNavigate(item.path);
                        onClose();
                      }}
                      className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-medium ${
                        active ? "bg-violet-50 text-violet-700" : "text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <Icon size={16} />
                      {item.label}
                    </button>
                  );
                })}
              </nav>
            </div>

            <div className="border-t border-violet-100 p-4">
              <button
                type="button"
                onClick={onLogout}
                className="flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
              >
                <LogOut size={16} />
                Logout
              </button>
            </div>
          </motion.aside>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}


function TrendCard({
  title,
  children,
  action,
}: {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <GlassPanel title={title} action={action}>
      {children}
    </GlassPanel>
  );
}

export function DashboardHero({ onPostJob, onViewApplications }: { onPostJob: () => void; onViewApplications: () => void }) {
  return (
    <section className="relative flex min-h-[calc(100vh-96px)] items-center overflow-hidden rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,#f5f3ff_0%,#faf9ff_55%,#ffffff_100%)] px-6 py-14 shadow-[0_24px_64px_rgba(124,58,237,0.10)] md:px-10 md:py-16">
      {/* animated background blobs */}
      <motion.div
        className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-violet-200/40 blur-3xl"
        animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0.8, 0.5] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="pointer-events-none absolute -right-20 bottom-0 h-80 w-80 rounded-full bg-fuchsia-200/40 blur-3xl"
        animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.7, 0.4] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />
      <motion.div
        className="pointer-events-none absolute left-1/2 top-1/3 h-64 w-64 -translate-x-1/2 rounded-full bg-sky-200/30 blur-3xl"
        animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.55, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
      />

      {/* decorative shapes */}
      <motion.div
        className="pointer-events-none absolute left-10 top-10 h-16 w-16 rounded-full border border-violet-200"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="pointer-events-none absolute right-10 top-16 h-14 w-14 rounded-2xl bg-violet-100/70"
        animate={{ y: [0, 10, 0], rotate: [0, 8, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative mx-auto flex max-w-3xl flex-col items-center text-center"
      >
        <motion.span
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.05 }}
          className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-white px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-violet-700 shadow-sm"
        >
          <Sparkles size={14} />
          AI-Powered Recruitment Platform
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="mt-6 text-4xl font-extrabold leading-tight tracking-tight text-slate-950 md:text-6xl lg:text-7xl"
        >
          Hire Smarter.
          <br />
          <span className="bg-[linear-gradient(135deg,#7c3aed,#a855f7)] bg-clip-text text-transparent">
            Build Stronger Teams.
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="mt-5 max-w-xl text-base leading-7 text-slate-500 md:text-lg"
        >
          HiredAI helps recruiters find the right talent faster with AI-driven screening,
          intelligent matching, and automated workflows.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.35 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-3"
        >
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            type="button"
            onClick={onPostJob}
            className="inline-flex items-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#7c3aed_0%,#6d28d9_100%)] px-6 py-3 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(124,58,237,0.30)] transition hover:opacity-90"
          >
            <Plus size={16} />
            Post New Job
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            type="button"
            onClick={onViewApplications}
            className="inline-flex items-center gap-2 rounded-2xl border border-violet-200 bg-white px-6 py-3 text-sm font-semibold text-violet-700 shadow-sm transition hover:bg-violet-50"
          >
            <FileText size={16} />
            View Applications
          </motion.button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.55 }}
          className="mt-12 grid w-full max-w-2xl grid-cols-2 gap-4 sm:grid-cols-4"
        >
          {[
            { label: "Active Jobs", value: "28" },
            { label: "Applications", value: "1,284" },
            { label: "Interviews", value: "46" },
            { label: "Hired", value: "17" },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 + i * 0.08 }}
              whileHover={{ y: -3 }}
              className="rounded-2xl border border-white/80 bg-white/70 px-3 py-4 shadow-[0_10px_28px_rgba(124,58,237,0.08)] backdrop-blur-xl"
            >
              <div className="text-2xl font-extrabold text-slate-950">{stat.value}</div>
              <div className="mt-1 text-xs font-medium text-slate-500">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      {/* left illustration: resume card */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0, y: [0, -12, 0] }}
        transition={{
          opacity: { duration: 0.6, delay: 0.4 },
          x: { duration: 0.6, delay: 0.4 },
          y: { duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 },
        }}
        className="pointer-events-none absolute left-6 bottom-10 hidden -rotate-6 md:block lg:left-14"
      >
        <div className="relative h-40 w-32 rounded-3xl bg-white shadow-[0_24px_60px_rgba(124,58,237,0.18)] ring-1 ring-violet-100">
          <div className="absolute inset-x-0 top-5 flex flex-col items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-violet-100 text-violet-600">
              <FileText size={18} />
            </div>
            <div className="h-2 w-16 rounded-full bg-violet-100" />
            <div className="h-2 w-12 rounded-full bg-violet-100" />
            <div className="h-2 w-14 rounded-full bg-violet-100" />
          </div>
          <div className="absolute -bottom-3 -right-3 grid h-9 w-9 place-items-center rounded-full bg-violet-600 text-white shadow-lg">
            <CircleCheckBig size={16} />
          </div>
        </div>
      </motion.div>

      {/* right illustration: people + search */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0, y: [0, 12, 0] }}
        transition={{
          opacity: { duration: 0.6, delay: 0.4 },
          x: { duration: 0.6, delay: 0.4 },
          y: { duration: 5.5, repeat: Infinity, ease: "easeInOut", delay: 1.2 },
        }}
        className="pointer-events-none absolute right-6 bottom-12 hidden items-end md:flex lg:right-14"
      >
        <div className="grid h-14 w-14 place-items-center rounded-full bg-violet-200/70 text-violet-500 shadow-md">
          <Users size={24} />
        </div>
        <div className="-ml-3 grid h-20 w-20 place-items-center rounded-full bg-violet-300/60 text-violet-600 shadow-lg">
          <Users size={30} />
        </div>
        <div className="-ml-3 grid h-16 w-16 place-items-center rounded-full bg-white text-violet-500 shadow-lg ring-1 ring-violet-100">
          <Search size={24} />
        </div>
      </motion.div>
    </section>
  );
}

function HomePage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-6">
      <DashboardHero
        onPostJob={() => navigate("/hr/post-job")}
        onViewApplications={() => navigate("/hr/applications")}
      />
      <HomeActiveJobsSection navigate={navigate} />
      <HomeTopCandidatesSection navigate={navigate} />
      <HomePipelineSection navigate={navigate} />
      <HomeInterviewsSection navigate={navigate} />
      <div>
        <HomeFAQSection />
        <HomeFooterSection navigate={navigate} />
      </div>
    </div>
  );
}

function HomeActiveJobsSection({ navigate }: { navigate: (path: string) => void }) {
  const activeJobs = JOBS.filter((job) => job.status === "Active").slice(0, 3);

  return (
    <GlassPanel
      title="Your active hiring"
      subtitle="Keep track of your open roles and see how candidates are progressing through each position."
      action={
        <button
          type="button"
          onClick={() => navigate("/hr/jobs")}
          className="inline-flex items-center gap-1 text-sm font-semibold text-violet-700 transition hover:text-violet-900"
        >
          View All Jobs <ArrowRight size={14} />
        </button>
      }
    >
      {activeJobs.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-3">
          {activeJobs.map((job, i) => (
            <motion.button
              key={job.id}
              type="button"
              onClick={() => navigate("/hr/jobs")}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.45, delay: i * 0.08, ease: "easeOut" }}
              whileHover={{ y: -4 }}
              className="flex flex-col rounded-[24px] border border-slate-100 bg-white/90 p-5 text-left shadow-[0_10px_28px_rgba(15,23,42,0.05)] transition hover:border-violet-200 hover:shadow-[0_16px_40px_rgba(124,58,237,0.14)]"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-bold text-slate-950">{job.title}</div>
                  <div className="mt-1 text-xs text-slate-500">{job.location} · Full-time</div>
                </div>
                <span className={`inline-flex shrink-0 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${statusTone(job.status)}`}>
                  {job.status}
                </span>
              </div>

              <div className="mt-4 flex items-center gap-4 text-sm">
                <div>
                  <div className="font-bold text-slate-950">{job.applications}</div>
                  <div className="text-xs text-slate-500">Applicants</div>
                </div>
                <div className="h-8 w-px bg-slate-100" />
                <div>
                  <div className="font-bold text-slate-950">{Math.round(job.applications * 0.3)}</div>
                  <div className="text-xs text-slate-500">Shortlisted</div>
                </div>
              </div>

              <div className="mt-4">
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${Math.min(job.atsAvg, 100)}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: 0.2 + i * 0.08, ease: "easeOut" }}
                    className="h-full rounded-full bg-[linear-gradient(90deg,#7c3aed,#a855f7)]"
                  />
                </div>
                <div className="mt-2 text-[11px] font-medium text-slate-400">{job.posted}</div>
              </div>
            </motion.button>
          ))}
        </div>
      ) : (
        <div className="rounded-[24px] border border-dashed border-slate-200 bg-slate-50/70 p-10 text-center">
          <div className="text-sm font-semibold text-slate-700">No active jobs yet</div>
          <p className="mt-1 text-sm text-slate-500">Create your first job post and start finding the right candidates.</p>
          <button
            type="button"
            onClick={() => navigate("/hr/post-job")}
            className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#7c3aed_0%,#6d28d9_100%)] px-5 py-2.5 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(124,58,237,0.30)]"
          >
            <Plus size={15} /> Post a New Job
          </button>
        </div>
      )}
    </GlassPanel>
  );
}

function HomeTopCandidatesSection({ navigate }: { navigate: (path: string) => void }) {
  const topCandidates = [...APPLICATIONS].sort((a, b) => b.score - a.score).slice(0, 3);

  return (
    <GlassPanel
      title="Top matching candidates"
      subtitle="AI-powered matching helps you quickly identify candidates whose skills and experience best fit your open roles."
      action={
        <button
          type="button"
          onClick={() => navigate("/hr/applications")}
          className="inline-flex items-center gap-1 text-sm font-semibold text-violet-700 transition hover:text-violet-900"
        >
          View All Candidates <ArrowRight size={14} />
        </button>
      }
    >
      <div className="grid gap-4 md:grid-cols-3">
        {topCandidates.map((c, i) => (
          <motion.button
            key={c.id}
            type="button"
            onClick={() => navigate("/hr/applications")}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.45, delay: i * 0.08, ease: "easeOut" }}
            whileHover={{ y: -4 }}
            className="flex flex-col rounded-[24px] border border-slate-100 bg-white/90 p-5 text-left shadow-[0_10px_28px_rgba(15,23,42,0.05)] transition hover:border-violet-200 hover:shadow-[0_16px_40px_rgba(124,58,237,0.14)]"
          >
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-full bg-[linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.10))] text-sm font-bold text-violet-700">
                {c.candidate.split(" ").map((p) => p[0]).join("")}
              </div>
              <div>
                <div className="font-bold text-slate-950">{c.candidate}</div>
                <div className="text-xs text-slate-500">{c.role}</div>
              </div>
            </div>

            <div className={`mt-4 inline-flex w-fit items-center gap-1 rounded-full px-3 py-1 text-xs font-bold ${c.score >= 90 ? "bg-emerald-50 text-emerald-700" : "bg-violet-50 text-violet-700"}`}>
              {c.score}% Match
            </div>

            <div className="mt-3 text-xs text-slate-500">{c.skillsMatch} skills match</div>

            <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-xs text-slate-500">
              <span>{c.experience}</span>
              <span>{c.location}</span>
            </div>
          </motion.button>
        ))}
      </div>
    </GlassPanel>
  );
}

function HomePipelineSection({ navigate }: { navigate: (path: string) => void }) {
  return (
    <GlassPanel
      title="Your hiring pipeline"
      subtitle="Get a quick overview of candidates moving through each stage of your recruitment process."
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {PIPELINE_DATA.map((stage, i) => (
          <motion.button
            key={stage.name}
            type="button"
            onClick={() => navigate("/hr/applications")}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.4, delay: i * 0.06, ease: "easeOut" }}
            whileHover={{ y: -4 }}
            className="relative flex flex-col items-center rounded-[22px] border border-slate-100 bg-white/90 px-3 py-5 text-center shadow-[0_10px_28px_rgba(15,23,42,0.05)] transition hover:border-violet-200"
          >
            <div
              className="grid h-10 w-10 place-items-center rounded-2xl text-white"
              style={{ background: `linear-gradient(135deg, ${stage.color}, ${stage.color}cc)` }}
            >
              <Users size={16} />
            </div>
            <div className="mt-3 text-xl font-extrabold text-slate-950">{currency(stage.value)}</div>
            <div className="mt-1 text-xs font-semibold text-slate-500">{stage.name}</div>
            {i < PIPELINE_DATA.length - 1 ? (
              <span className="absolute -right-2 top-1/2 hidden h-px w-4 -translate-y-1/2 bg-slate-200 xl:block" />
            ) : null}
          </motion.button>
        ))}
      </div>
    </GlassPanel>
  );
}

function HomeInterviewsSection({ navigate }: { navigate: (path: string) => void }) {
  return (
    <GlassPanel
      title="Upcoming interviews"
      subtitle="Stay on top of scheduled conversations and make sure no candidate interaction is missed."
      action={
        <button
          type="button"
          onClick={() => navigate("/hr/interviews")}
          className="inline-flex items-center gap-1 text-sm font-semibold text-violet-700 transition hover:text-violet-900"
        >
          View Calendar <ArrowRight size={14} />
        </button>
      }
    >
      {INTERVIEWS.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-3">
          {INTERVIEWS.map((item, i) => (
            <motion.button
              key={`${item.candidate}-${item.time}`}
              type="button"
              onClick={() => navigate("/hr/interviews")}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.45, delay: i * 0.08, ease: "easeOut" }}
              whileHover={{ y: -4 }}
              className="flex flex-col rounded-[24px] border border-slate-100 bg-white/90 p-5 text-left shadow-[0_10px_28px_rgba(15,23,42,0.05)] transition hover:border-violet-200 hover:shadow-[0_16px_40px_rgba(124,58,237,0.14)]"
            >
              <div className="flex items-center justify-between">
                <div className="inline-flex items-center gap-2 rounded-full bg-violet-50 px-3 py-1 text-xs font-bold text-violet-700">
                  <Clock3 size={12} /> {item.time}
                </div>
                <span className={`inline-flex h-2.5 w-2.5 rounded-full ${statusDot(item.status)}`} />
              </div>
              <div className="mt-3 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-[linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.10))] text-xs font-bold text-violet-700">
                  {item.candidate.split(" ").map((p) => p[0]).join("")}
                </div>
                <div>
                  <div className="font-bold text-slate-950">{item.candidate}</div>
                  <div className="text-xs text-slate-500">{item.role}</div>
                </div>
              </div>
              <div className="mt-4 text-xs font-medium text-slate-400">{item.type}</div>
            </motion.button>
          ))}
        </div>
      ) : (
        <div className="rounded-[24px] border border-dashed border-slate-200 bg-slate-50/70 p-10 text-center">
          <div className="text-sm font-semibold text-slate-700">No upcoming interviews</div>
          <p className="mt-1 text-sm text-slate-500">Scheduled candidate interviews will appear here.</p>
        </div>
      )}
    </GlassPanel>
  );
}

function LinkedInGlyph({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1 4.98 2.12 4.98 3.5zM.5 8h4V23h-4V8zM8.5 8h3.83v2.05h.05c.53-1 1.83-2.05 3.77-2.05C20.6 8 22 10.2 22 14.05V23h-4v-7.9c0-1.88-.03-4.3-2.62-4.3-2.63 0-3.03 2.05-3.03 4.17V23h-4V8z" />
    </svg>
  );
}

function InstagramGlyph({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

function XGlyph({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.9 2H22l-7.5 8.57L23.3 22h-6.9l-5.4-6.6L4.7 22H1.6l8.03-9.18L1 2h7.1l4.9 6.03L18.9 2zm-1.2 18.2h1.9L7.4 3.7H5.4l12.3 16.5z" />
    </svg>
  );
}

const RECRUITER_FAQS = [
  {
    q: "What is the HiredAI Recruiter Portal?",
    a: "It's your all-in-one hiring workspace — post jobs, screen candidates with AI-powered matching, manage your pipeline, and schedule interviews from a single dashboard.",
  },
  {
    q: "How does AI candidate matching work?",
    a: "HiredAI analyzes resumes against your job requirements and scores each candidate on skills, experience, and role fit, so you can focus on the strongest applicants first.",
  },
  {
    q: "How is the ATS score calculated?",
    a: "The ATS score combines skills match, years of experience, education relevance, and keyword alignment with your job description into a single 0-100 score.",
  },
  {
    q: "Can I customize my hiring pipeline stages?",
    a: "Yes. The default stages are Applied, Reviewed, Shortlisted, Interview, Offer, and Hired, and you can adjust workflow preferences from Settings.",
  },
  {
    q: "How do I schedule and manage interviews?",
    a: "Open the Interviews tab to see upcoming sessions, join meetings directly, and track interview status in real time.",
  },
  {
    q: "Is my company and candidate data secure?",
    a: "Yes. All recruiter and candidate data is encrypted and access is restricted to your verified organization account.",
  },
];

function HomeFAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="rounded-t-[30px] border border-white/10 bg-[#0b0c14] p-6 shadow-[0_24px_64px_rgba(0,0,0,0.35)] md:p-10"
    >
      <div className="mx-auto max-w-3xl text-center">
        <h2 className="text-2xl font-extrabold tracking-tight text-white md:text-4xl">Frequently asked questions</h2>
        <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-400 md:text-base">
          Quick answers about hiring, AI matching, and how the portal works.
        </p>
      </div>

      <div className="mx-auto mt-8 max-w-3xl divide-y divide-white/10">
        {RECRUITER_FAQS.map((item, i) => {
          const open = openIndex === i;
          return (
            <motion.div
              key={item.q}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.35, delay: i * 0.05, ease: "easeOut" }}
            >
              <button
                type="button"
                onClick={() => setOpenIndex(open ? null : i)}
                className="flex w-full items-center justify-between gap-4 py-5 text-left"
              >
                <span className="text-base font-semibold text-white">{item.q}</span>
                <motion.span
                  animate={{ rotate: open ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                   className="shrink-0 text-white"
                >
                  <ChevronDown size={16} />
                </motion.span>
              </button>
              <AnimatePresence initial={false}>
                {open ? (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                    className="overflow-hidden"
                  >
                    <p className="pb-5 text-sm leading-6 text-slate-400">{item.a}</p>
                  </motion.div>
                ) : null}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </motion.section>
  );
}

function HomeFooterSection({ navigate }: { navigate: (path: string) => void }) {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const columns = [
    {
      title: "Product",
      links: [
        { label: "Post a Job", path: "/hr/post-job" },
        { label: "Candidate Search", path: "/hr/applications" },
        { label: "Hiring Analytics", path: "/hr/shortlisted" },
        { label: "Interview Scheduling", path: "/hr/interviews" },
      ],
    },
    {
      title: "Company",
      links: [
        { label: "Company Profile", path: "/hr/company" },
        { label: "Settings", path: "/hr/settings" },
        { label: "Privacy", path: "#" },
        { label: "Terms", path: "#" },
      ],
    },
    {
      title: "Support",
      links: [
        { label: "Contact", path: "#" },
        { label: "Help Center", path: "#" },
        { label: "FAQ", path: "#" },
        { label: "Community", path: "#" },
      ],
    },
  ];

  return (
    <motion.footer
  initial={{ opacity: 0, y: 20 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, margin: "-40px" }}
  transition={{ duration: 0.5, ease: "easeOut" }}
  className="rounded-b-[30px] border border-white/10 border-t-0 bg-[#0b0c14] p-6 shadow-[0_24px_64px_rgba(0,0,0,0.35)] md:p-10"
>
      <div className="grid gap-10 lg:grid-cols-[1.1fr_1.4fr]">
        <div>
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10 ring-1 ring-white/15">
              <Sparkles size={20} className="text-violet-400" />
            </div>
            <div className="text-lg font-extrabold tracking-tight text-white">
              Hired<span className="text-violet-400">AI</span>
            </div>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-6 text-slate-400">
            Your AI-powered hiring partner — from posting roles to matching, screening, and scheduling the right candidates faster.
          </p>
          <div className="mt-5 flex items-center gap-3">
            {[LinkedInGlyph, InstagramGlyph, XGlyph].map((Icon, i) => (
              <motion.a
                key={i}
                href="#"
                whileHover={{ y: -3, scale: 1.06 }}
                whileTap={{ scale: 0.94 }}
                className="grid h-10 w-10 place-items-center rounded-full border border-white/15 bg-white/5 text-white transition hover:bg-white/10"
              >
                <Icon size={16} />
              </motion.a>
            ))}
          </div>
        </div>

        <div className="grid gap-8 sm:grid-cols-3">
          {columns.map((col, ci) => (
            <motion.div
              key={col.title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: ci * 0.08, ease: "easeOut" }}
            >
              <div className="text-xs font-bold uppercase tracking-[0.18em] text-slate-500">{col.title}</div>
              <ul className="mt-4 space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <button
                      type="button"
                      onClick={() => (link.path !== "#" ? navigate(link.path) : undefined)}
                      className="text-sm text-slate-300 transition hover:text-violet-400"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="mt-10 flex flex-col gap-4 border-t border-white/10 pt-8 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="text-sm font-bold text-white">Stay in the loop</div>
          <p className="mt-1 text-sm text-slate-400">Hiring tips, product updates, and recruiter insights — weekly.</p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (email) setSubscribed(true);
          }}
          className="flex gap-2"
        >
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-56 rounded-2xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-violet-400"
          />
          <motion.button
            type="submit"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="rounded-2xl bg-[linear-gradient(135deg,#7c3aed_0%,#6d28d9_100%)] px-5 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_rgba(124,58,237,0.35)]"
          >
            <AnimatePresence mode="wait">
              <motion.span key={subscribed ? "done" : "sub"} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }}>
                {subscribed ? "Subscribed ✓" : "Subscribe"}
              </motion.span>
            </AnimatePresence>
          </motion.button>
        </form>
      </div>

      <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-slate-500 sm:flex-row">
        <span>© 2026 HiredAI. All rights reserved.</span>
        <div className="flex gap-5">
          <button type="button" className="transition hover:text-violet-400">Privacy Policy</button>
          <button type="button" className="transition hover:text-violet-400">Terms of Service</button>
          <button type="button" className="transition hover:text-violet-400">Cookie Policy</button>
        </div>
      </div>
    </motion.footer>
  );
}
function DashboardPage() {
  const maxFunnel = 478;

  return (
    <div className="space-y-5">
      <section className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-5">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="rounded-[30px] border border-white/70 bg-white/80 px-6 py-6 shadow-[0_20px_60px_rgba(15,23,42,0.06)] backdrop-blur-2xl"
          >
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-950 md:text-4xl">Hiring dashboard</h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-500">
              Welcome back, Varshan! Here&apos;s what&apos;s happening in your workspace.
            </p>
          </motion.div>

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {DASHBOARD_STATS.map((stat, i) => (
              <MetricCard key={stat.label} index={i} {...stat} />
            ))}
          </div>

          <div className="grid gap-5 xl:grid-cols-[minmax(0,1.6fr)_minmax(320px,0.9fr)]">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            >
              <GlassPanel
                title="Applications over time"
                action={
                  <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-semibold text-slate-700">
                    Last 7 days
                    <ChevronRight size={13} className="rotate-90" />
                  </span>
                }
              >
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={DASHBOARD_TREND_DATA} margin={{ top: 10, right: 8, bottom: 0, left: -8 }}>
                      <defs>
                        <linearGradient id="dashboardApps" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#7c3aed" stopOpacity={0.28} />
                          <stop offset="100%" stopColor="#7c3aed" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid vertical={false} strokeDasharray="4 4" stroke="#ede9fe" />
                      <XAxis dataKey="name" tickLine={false} axisLine={false} tick={{ fill: "#64748b", fontSize: 12 }} />
                      <YAxis tickLine={false} axisLine={false} tick={{ fill: "#64748b", fontSize: 12 }} domain={[0, 400]} ticks={[0, 100, 200, 300, 400]} />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="applications"
                        stroke="#6d28d9"
                        strokeWidth={2.5}
                        fill="url(#dashboardApps)"
                        dot={{ r: 5, strokeWidth: 2, stroke: "#6d28d9", fill: "#ffffff" }}
                        activeDot={{ r: 7 }}
                        isAnimationActive
                        animationDuration={1100}
                        animationEasing="ease-out"
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </GlassPanel>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
            >
              <GlassPanel title="Hiring funnel">
                <div className="space-y-4">
                  {[
                    { label: "Applied", value: 478, icon: ArrowRight, tone: "bg-violet-50 text-violet-600", bar: "#7c3aed" },
                    { label: "Reviewed", value: 186, icon: Activity, tone: "bg-sky-50 text-sky-600", bar: "#0ea5e9" },
                    { label: "Shortlisted", value: 102, icon: Star, tone: "bg-purple-50 text-purple-600", bar: "#a855f7" },
                    { label: "Interview", value: 34, icon: CalendarDays, tone: "bg-amber-50 text-amber-600", bar: "#f59e0b" },
                    { label: "Offer", value: 14, icon: ShieldCheck, tone: "bg-orange-50 text-orange-600", bar: "#fb923c" },
                    { label: "Hired", value: 17, icon: Users, tone: "bg-emerald-50 text-emerald-600", bar: "#10b981" },
                  ].map((stage, i) => {
                    const Icon = stage.icon;
                    return (
                      <motion.div
                        key={stage.label}
                        initial={{ opacity: 0, x: -12 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-30px" }}
                        transition={{ duration: 0.35, delay: i * 0.06, ease: "easeOut" }}
                        whileHover={{ x: 3 }}
                        className="rounded-[22px] px-4 py-3 transition hover:bg-slate-50"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`grid h-11 w-11 place-items-center rounded-2xl ${stage.tone}`}>
                              <Icon size={18} />
                            </div>
                            <div className="text-sm font-semibold text-slate-950">{stage.label}</div>
                          </div>
                          <div className="text-sm font-semibold text-slate-700">{currency(stage.value)}</div>
                        </div>
                        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${Math.max((stage.value / maxFunnel) * 100, 3)}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8, delay: 0.15 + i * 0.06, ease: "easeOut" }}
                            className="h-full rounded-full"
                            style={{ backgroundColor: stage.bar }}
                          />
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </GlassPanel>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <GlassPanel title="Recent applications" subtitle="Fast review table with score badges, skill tags, and actions.">
              <div className="overflow-hidden rounded-[24px] border border-slate-100 bg-white">
                <table className="w-full text-left">
                  <thead className="bg-slate-50/90 text-xs uppercase tracking-[0.16em] text-slate-500">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Candidate</th>
                      <th className="px-4 py-3 font-semibold">Role</th>
                      <th className="px-4 py-3 font-semibold">ATS Score</th>
                      <th className="px-4 py-3 font-semibold">Experience</th>
                      <th className="px-4 py-3 font-semibold">Applied</th>
                      <th className="px-4 py-3 font-semibold">Status</th>
                      <th className="px-4 py-3 font-semibold" />
                    </tr>
                  </thead>
                  <tbody>
                    {DASHBOARD_APPLICATIONS.map((app, i) => (
                      <motion.tr
                        key={app.id}
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true, margin: "-30px" }}
                        transition={{ duration: 0.35, delay: i * 0.06, ease: "easeOut" }}
                        className="border-t border-slate-100 transition hover:bg-violet-50/30"
                      >
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <div className="grid h-11 w-11 place-items-center rounded-full bg-[linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.10))] text-sm font-bold text-violet-700">
                              {app.initials}
                            </div>
                            <div>
                              <div className="font-semibold text-slate-950">{app.candidate}</div>
                              <div className="text-xs text-slate-500">{app.role}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-sm font-medium text-slate-700">{app.role}</td>
                        <td className="px-4 py-4">
                          <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">{app.ats}%</span>
                        </td>
                        <td className="px-4 py-4 text-sm text-slate-700">{app.experience}</td>
                        <td className="px-4 py-4 text-sm text-slate-700">{app.applied}</td>
                        <td className="px-4 py-4">
                          <span className={`rounded-full px-3 py-1 text-xs font-semibold ${applicationTone(app.status)}`}>{app.status}</span>
                        </td>
                        <td className="px-4 py-4">
                          <button type="button" className="rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700">
                            <MoreHorizontal size={16} />
                          </button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </GlassPanel>
          </motion.div>
        </div>

        <div className="space-y-5">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <GlassPanel title="Recent activity" subtitle="What happened in the hiring workspace this week.">
              <div className="space-y-4">
                {DASHBOARD_ACTIVITY.map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <motion.div
                      key={item.title}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: "-30px" }}
                      transition={{ duration: 0.4, delay: i * 0.1, ease: "easeOut" }}
                      whileHover={{ y: -3 }}
                      className="rounded-[22px] border border-slate-100 bg-white/90 p-4 shadow-[0_10px_28px_rgba(15,23,42,0.04)] transition-shadow hover:shadow-[0_16px_36px_rgba(124,58,237,0.12)]"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`grid h-10 w-10 place-items-center rounded-2xl ${item.tone}`}>
                          <Icon size={16} />
                        </div>
                        <div>
                          <div className="font-semibold text-slate-950">{item.title}</div>
                          <div className="mt-1 text-sm leading-6 text-slate-500">{item.subtitle}</div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </GlassPanel>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
          >
            <GlassPanel title="Pipeline" subtitle="Drag-ready workflow stages for quick candidate movement.">
              <div className="space-y-3">
                {DASHBOARD_PIPELINE.map((stage, i) => (
                  <motion.div
                    key={stage.stage}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-30px" }}
                    transition={{ duration: 0.4, delay: i * 0.08, ease: "easeOut" }}
                    whileHover={{ y: -3 }}
                    className="group rounded-[22px] border border-slate-100 bg-white/90 p-4 shadow-[0_10px_28px_rgba(15,23,42,0.04)] transition-shadow hover:shadow-[0_16px_36px_rgba(124,58,237,0.12)]"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-slate-950">{stage.stage}</span>
                        <span className="rounded-full bg-violet-50 px-2 py-0.5 text-[11px] font-bold text-violet-600">{stage.count}</span>
                      </div>
                      <ChevronRight size={14} className="text-slate-400 transition-transform group-hover:translate-x-1" />
                    </div>
                    <div className="mt-3 rounded-[18px] border border-slate-100 bg-[linear-gradient(135deg,rgba(124,58,237,0.06),rgba(255,255,255,0.96))] p-3">
                      <div className="text-sm font-semibold text-slate-950">{stage.candidate}</div>
                      {stage.role ? <div className="text-xs text-slate-500">{stage.role}</div> : <div className="text-xs text-slate-500">No candidates yet</div>}
                    </div>
                    <div className="mt-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-violet-500 transition-transform group-hover:translate-x-1">
                      <ArrowRight size={12} />
                      Next stage
                    </div>
                  </motion.div>
                ))}
              </div>
            </GlassPanel>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
function JobsPage() {
  return (
    <div className="grid gap-5 xl:grid-cols-[1.4fr_0.9fr]">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <GlassPanel title="My Jobs" subtitle="Track live roles, score distribution, and posted status at a glance.">
          <div className="overflow-hidden rounded-[26px] border border-slate-100 bg-white/80">
            <table className="w-full text-left">
              <thead className="bg-slate-50/90 text-xs uppercase tracking-[0.18em] text-slate-500">
                <tr>
                  <th className="px-4 py-3">Job</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Applications</th>
                  <th className="px-4 py-3">ATS Avg</th>
                  <th className="px-4 py-3">Location</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {JOBS.map((job, i) => (
                  <motion.tr
                    key={job.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.35, delay: i * 0.06, ease: "easeOut" }}
                    className="border-t border-slate-100 transition hover:bg-violet-50/30"
                  >
                    <td className="px-4 py-4">
                      <div className="font-semibold text-slate-950">{job.title}</div>
                      <div className="text-xs text-slate-500">{job.id} - {job.posted}</div>
                    </td>
                    <td className="px-4 py-4 text-sm text-slate-700">{job.department}</td>
                    <td className="px-4 py-4">
                      <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusTone(job.status)}`}>{job.status}</span>
                    </td>
                    <td className="px-4 py-4 text-sm font-semibold text-slate-900">{currency(job.applications)}</td>
                    <td className="px-4 py-4">
                      {job.atsAvg ? (
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-14 overflow-hidden rounded-full bg-slate-100">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${job.atsAvg}%` }}
                              transition={{ duration: 0.7, delay: 0.2 + i * 0.06, ease: "easeOut" }}
                              className="h-full rounded-full bg-[linear-gradient(90deg,#7c3aed,#a855f7)]"
                            />
                          </div>
                          <span className="text-sm font-semibold text-slate-900">{job.atsAvg}%</span>
                        </div>
                      ) : (
                        <span className="text-sm text-slate-400">-</span>
                      )}
                    </td>
                    <td className="px-4 py-4 text-sm text-slate-700">{job.location}</td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2 text-slate-500">
                        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.92 }} className="rounded-xl border border-slate-200 p-2 hover:border-violet-200 hover:text-violet-700">
                          <PencilLine size={15} />
                        </motion.button>
                        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.92 }} className="rounded-xl border border-slate-200 p-2 hover:border-violet-200 hover:text-violet-700">
                          <MoreHorizontal size={15} />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassPanel>
      </motion.div>

      <div className="grid gap-5">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}
        >
          <GlassPanel title="Hiring analytics" subtitle="Compact trend view for job-level performance.">
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={JOBS}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#EDE9F8" />
                  <XAxis dataKey="title" tickLine={false} axisLine={false} hide />
                  <YAxis tickLine={false} axisLine={false} />
                  <Tooltip />
                  <Bar dataKey="applications" radius={[12, 12, 0, 0]} isAnimationActive animationDuration={900} animationEasing="ease-out">
                    {JOBS.map((entry, index) => (
                      <Cell key={entry.id} fill={index % 2 === 0 ? "#7c3aed" : "#06b6d4"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </GlassPanel>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.18, ease: "easeOut" }}
        >
          <GlassPanel title="Create from template" subtitle="Quick actions for the next posting.">
            <div className="grid gap-3 sm:grid-cols-2">
              {["Product Designer", "Backend Engineer", "Data Scientist", "DevOps Engineer"].map((role, i) => (
                <motion.button
                  key={role}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: 0.25 + i * 0.06, ease: "easeOut" }}
                  whileHover={{ y: -3, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="rounded-[22px] border border-slate-100 bg-white/80 px-4 py-4 text-left text-sm font-semibold text-slate-700 transition hover:border-violet-200 hover:text-violet-700"
                >
                  {role}
                </motion.button>
              ))}
            </div>
          </GlassPanel>
        </motion.div>
      </div>
    </div>
  );
}

function ApplicationsPage() {
  const [selectedId, setSelectedId] = useState(APPLICATIONS[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const filtered = useMemo(
    () => APPLICATIONS.filter((app) => `${app.candidate} ${app.role} ${app.location}`.toLowerCase().includes(query.toLowerCase())),
    [query],
  );
  const selected = filtered.find((item) => item.id === selectedId) ?? filtered[0] ?? APPLICATIONS[0];

  return (
    <div className="grid gap-5 xl:grid-cols-[1.35fr_0.85fr]">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: "easeOut" }}>
        <GlassPanel
          title="Applications"
          subtitle="Professional review table with avatar, ATS score, experience, and workflow status."
          action={
            <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search candidate"
                className="w-44 bg-transparent text-sm outline-none placeholder:text-slate-400"
              />
            </div>
          }
        >
          <div className="overflow-hidden rounded-[26px] border border-slate-100 bg-white/80">
            <table className="w-full text-left">
              <thead className="bg-slate-50/90 text-xs uppercase tracking-[0.18em] text-slate-500">
                <tr>
                  <th className="px-4 py-3">Candidate</th>
                  <th className="px-4 py-3">ATS Score</th>
                  <th className="px-4 py-3">Experience</th>
                  <th className="px-4 py-3">Skills</th>
                  <th className="px-4 py-3">Applied</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence mode="popLayout">
                  {filtered.map((app, i) => (
                    <motion.tr
                      key={app.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3, delay: i * 0.05, ease: "easeOut" }}
                      onClick={() => setSelectedId(app.id)}
                      className={`cursor-pointer border-t border-slate-100 transition hover:bg-violet-50/40 ${selected?.id === app.id ? "bg-violet-50/70" : ""}`}
                    >
                      <td className="px-4 py-4">
                        <div className="font-semibold text-slate-950">{app.candidate}</div>
                        <div className="text-xs text-slate-500">{app.role} - {app.location}</div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700">{app.score}%</span>
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-700">{app.experience}</td>
                      <td className="px-4 py-4 text-sm text-slate-700">{app.skillsMatch}</td>
                      <td className="px-4 py-4 text-sm text-slate-700">{app.appliedDate}</td>
                      <td className="px-4 py-4">
                        <span className={`rounded-full px-3 py-1 text-xs font-semibold ${applicationTone(app.status)}`}>{app.status}</span>
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </GlassPanel>
      </motion.div>

      <div className="space-y-5">
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}>
          <GlassPanel title="Candidate detail" subtitle="A focused review panel with ATS context and notes.">
            <AnimatePresence mode="wait">
              <motion.div
                key={selected.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className="space-y-4"
              >
                <div className="rounded-[26px] bg-[linear-gradient(135deg,#7c3aed_0%,#6d28d9_100%)] p-5 text-white shadow-[0_24px_64px_rgba(124,58,237,0.18)]">
                  <div className="text-xs font-semibold uppercase tracking-[0.24em] text-violet-200">ATS Score</div>
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: 0.1, type: "spring", stiffness: 200 }}
                    className="mt-2 text-4xl font-extrabold"
                  >
                    {selected.score}
                  </motion.div>
                  <div className="mt-1 text-sm text-violet-100">Strong fit for {selected.role}</div>
                </div>
                <div className="rounded-[26px] border border-slate-100 bg-white/80 p-5">
                  <div className="text-lg font-bold text-slate-950">{selected.candidate}</div>
                  <div className="text-sm text-slate-500">{selected.role}</div>
                  <div className="mt-4 grid gap-3 text-sm">
                    <div><span className="font-semibold text-slate-800">Experience:</span> {selected.experience}</div>
                    <div><span className="font-semibold text-slate-800">Education:</span> {selected.education}</div>
                    <div><span className="font-semibold text-slate-800">Skills match:</span> {selected.skillsMatch}</div>
                    <div><span className="font-semibold text-slate-800">Location:</span> {selected.location}</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {["Resume", "Download", "Notes", "Shortlist"].map((label) => (
                    <motion.button
                      key={label}
                      whileHover={{ y: -2, scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
                    >
                      {label}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </GlassPanel>
        </motion.div>
      </div>
    </div>
  );
}

function ShortlistedPage() {
  return (
    <GlassPanel title="Shortlisted candidates" subtitle="A kanban-ready pipeline view with clean stage cards.">
      <div className="grid gap-4 overflow-x-auto pb-2 xl:grid-cols-6">
        {PIPELINE_COLUMNS.map((stage, colIndex) => (
          <motion.div
            key={stage.title}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: colIndex * 0.08, ease: "easeOut" }}
            className="min-w-[220px] rounded-[24px] border border-slate-100 bg-white/80 p-4"
          >
            <div className="mb-3 flex items-center justify-between">
              <div className="text-sm font-semibold text-slate-900">{stage.title}</div>
              <div className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-500">{stage.items.length}</div>
            </div>
            <div className="space-y-2">
              {stage.items.slice(0, 2).map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.35, delay: colIndex * 0.08 + 0.1 + i * 0.06, ease: "easeOut" }}
                  whileHover={{ y: -3, scale: 1.02 }}
                  className="cursor-pointer rounded-2xl border border-slate-100 bg-[linear-gradient(135deg,rgba(124,58,237,0.06),rgba(255,255,255,0.95))] p-3 shadow-[0_6px_18px_rgba(15,23,42,0.04)] transition-shadow hover:shadow-[0_12px_30px_rgba(124,58,237,0.14)]"
                >
                  <div className="text-sm font-semibold text-slate-950">{item.candidate}</div>
                  <div className="text-xs text-slate-500">{item.role}</div>
                </motion.div>
              ))}
              {stage.items.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50/80 p-3 text-xs text-slate-400">
                  Empty stage
                </div>
              ) : null}
            </div>
          </motion.div>
        ))}
      </div>
    </GlassPanel>
  );
}

function JobFormPage() {
  const steps = ["Basics", "Compensation", "Requirements", "Publish"];
  const [step, setStep] = useState(0);

  return (
    <div className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
      <GlassPanel title="Post a Job" subtitle="A cleaner, premium version of the same posting flow.">
        <div className="mb-6 flex flex-wrap items-center gap-3">
          {steps.map((label, index) => (
            <div key={label} className="flex items-center gap-3">
              <div className={`grid h-8 w-8 place-items-center rounded-full text-xs font-bold ${index <= step ? "bg-violet-600 text-white" : "bg-slate-100 text-slate-500"}`}>{index + 1}</div>
              <div className={`text-sm font-semibold ${index <= step ? "text-slate-950" : "text-slate-400"}`}>{label}</div>
              {index < steps.length - 1 ? <div className="mx-1 h-px w-8 bg-slate-200" /> : null}
            </div>
          ))}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {["Job title", "Department", "Employment type", "Work mode", "Location", "Experience", "Salary range", "Number of openings"].map((label) => (
            <label key={label} className="block">
              <span className="mb-2 block text-sm font-semibold text-slate-700">{label}</span>
              <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-violet-400 focus:bg-white" placeholder={label} />
            </label>
          ))}
          <label className="block md:col-span-2">
            <span className="mb-2 block text-sm font-semibold text-slate-700">Job description</span>
            <textarea className="min-h-36 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-violet-400 focus:bg-white" placeholder="Describe the role, responsibilities, and impact..." />
          </label>
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <button onClick={() => setStep((s) => Math.max(0, s - 1))} className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700">Back</button>
          <button onClick={() => setStep((s) => Math.min(steps.length - 1, s + 1))} className="rounded-2xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white">Next</button>
          <button className="rounded-2xl border border-violet-200 bg-violet-50 px-5 py-3 text-sm font-semibold text-violet-700">Save as Draft</button>
          <button className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700">Preview Job</button>
          <button className="rounded-2xl bg-[linear-gradient(135deg,#7c3aed_0%,#6d28d9_100%)] px-5 py-3 text-sm font-semibold text-white shadow-[0_8px_20px_rgba(124,58,237,0.24)]">Publish Job</button>
        </div>
      </GlassPanel>

      <div className="space-y-5">
        <GlassPanel title="Live preview" subtitle="A recruiter-facing snapshot of the final posting.">
          <div className="rounded-[26px] border border-slate-100 bg-[linear-gradient(180deg,rgba(248,247,255,0.9),rgba(255,255,255,0.95))] p-5">
            <div className="text-xs font-semibold uppercase tracking-[0.24em] text-violet-500">Preview</div>
            <div className="mt-3 text-2xl font-extrabold tracking-tight text-slate-950">Senior Product Designer</div>
            <div className="mt-2 flex flex-wrap gap-2 text-sm text-slate-600">
              <span className="rounded-full bg-white px-3 py-1 shadow-sm">Remote</span>
              <span className="rounded-full bg-white px-3 py-1 shadow-sm">Full time</span>
              <span className="rounded-full bg-white px-3 py-1 shadow-sm">4-8 years</span>
            </div>
            <p className="mt-4 text-sm leading-6 text-slate-600">Design intuitive product flows, own design systems, and work closely with product and engineering on high-impact shipping cycles.</p>
          </div>
        </GlassPanel>

        <GlassPanel title="Publishing checklist" subtitle="Everything aligned before a role goes live.">
          <div className="space-y-3 text-sm text-slate-600">
            {[
              "Review required skills and compensation",
              "Check application deadline",
              "Confirm interview stages",
              "Validate job visibility and ATS integration",
            ].map((item) => (
              <div key={item} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-white/80 px-4 py-3">
                <CircleCheckBig size={16} className="text-emerald-500" />
                {item}
              </div>
            ))}
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}

function CompanyPage() {
  return (
    <div className="grid gap-5 xl:grid-cols-[0.95fr_1.05fr]">
      <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, ease: "easeOut" }}>
        <GlassPanel title="Company profile" subtitle="Brand, role, and company metadata in one clean panel.">
          <div className="grid gap-4">
            {["Company logo", "Company name", "Industry", "Website", "Company size", "Headquarters"].map((label, i) => (
              <motion.label
                key={label}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.05, ease: "easeOut" }}
                className="block"
              >
                <span className="mb-2 block text-sm font-semibold text-slate-700">{label}</span>
                <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-violet-400 focus:bg-white" />
              </motion.label>
            ))}
            <motion.label
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3, ease: "easeOut" }}
              className="block"
            >
              <span className="mb-2 block text-sm font-semibold text-slate-700">About company</span>
              <textarea className="min-h-36 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-violet-400 focus:bg-white" defaultValue="We build products that help candidates and recruiters move faster with AI." />
            </motion.label>
          </div>
        </GlassPanel>
      </motion.div>

      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}>
        <GlassPanel title="Recruiter details" subtitle="Contact and verification information for the hiring team.">
          <div className="grid gap-4 md:grid-cols-2">
            {["Recruiter name", "Work email", "Phone", "Verification status"].map((label, i) => (
              <motion.label
                key={label}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.06, ease: "easeOut" }}
                className="block"
              >
                <span className="mb-2 block text-sm font-semibold text-slate-700">{label}</span>
                <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-violet-400 focus:bg-white" />
              </motion.label>
            ))}
            <motion.label
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3, ease: "easeOut" }}
              className="block md:col-span-2"
            >
              <span className="mb-2 block text-sm font-semibold text-slate-700">Social links</span>
              <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-violet-400 focus:bg-white" placeholder="LinkedIn, X, website..." />
            </motion.label>
            <div className="md:col-span-2 flex gap-3">
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700">
                Save changes
              </motion.button>
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} className="rounded-2xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white">
                Request verification
              </motion.button>
            </div>
          </div>
        </GlassPanel>
      </motion.div>
    </div>
  );
}

function ToggleSwitch({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button
      type="button"
      onClick={onChange}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${checked ? "bg-violet-600" : "bg-slate-200"}`}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-md"
        style={{ left: checked ? 22 : 2 }}
      />
    </button>
  );
}

function SettingsPage() {
  const [notifPrefs, setNotifPrefs] = useState({
    "New applications": true,
    "Interview reminders": true,
    "Job expiry": true,
    "Hiring completed": true,
    "Application updates": true,
  });
  const [saved, setSaved] = useState(false);

  const toggle = (key: string) => setNotifPrefs((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }));

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  };

  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_1fr]">
      <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, ease: "easeOut" }}>
        <GlassPanel title="Notifications" subtitle="Fine-tune which recruiter alerts stay visible.">
          <div className="space-y-3">
            {Object.keys(notifPrefs).map((label, i) => (
              <motion.label
                key={label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: i * 0.06, ease: "easeOut" }}
                className="flex items-center justify-between rounded-2xl border border-slate-100 bg-white/80 px-4 py-3 transition hover:border-violet-200"
              >
                <span className="text-sm font-semibold text-slate-700">{label}</span>
                <ToggleSwitch checked={notifPrefs[label as keyof typeof notifPrefs]} onChange={() => toggle(label)} />
              </motion.label>
            ))}
          </div>
        </GlassPanel>
      </motion.div>

      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}>
        <GlassPanel title="Workspace preferences" subtitle="Default filters and column choices for hiring decisions.">
          <div className="space-y-4 text-sm text-slate-600">
            {[
              <>Default hiring stage: <span className="font-semibold text-slate-900">Shortlisted</span></>,
              <>ATS sorting: <span className="font-semibold text-slate-900">Highest score first</span></>,
              <>Visible columns: Candidate, ATS Score, Skills Match, Status</>,
            ].map((content, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: i * 0.08, ease: "easeOut" }}
                className="rounded-2xl border border-slate-100 bg-white/80 px-4 py-3"
              >
                {content}
              </motion.div>
            ))}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleSave}
              className="relative overflow-hidden rounded-2xl bg-[linear-gradient(135deg,#7c3aed_0%,#6d28d9_100%)] px-5 py-3 text-sm font-semibold text-white shadow-[0_8px_20px_rgba(124,58,237,0.24)]"
            >
              <AnimatePresence mode="wait">
                <motion.span
                  key={saved ? "saved" : "save"}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-2"
                >
                  {saved ? (
                    <>
                      <CircleCheckBig size={16} /> Saved
                    </>
                  ) : (
                    "Save settings"
                  )}
                </motion.span>
              </AnimatePresence>
            </motion.button>
          </div>
        </GlassPanel>
      </motion.div>
    </div>
  );
}

function InterviewsPage() {
  return (
    <GlassPanel title="Interviews" subtitle="Timeline-style cards for the day ahead.">
      <div className="grid gap-4 md:grid-cols-3">
        {INTERVIEWS.map((item, i) => (
          <motion.div
            key={`${item.candidate}-${item.time}`}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.1, ease: "easeOut" }}
            whileHover={{ y: -4 }}
            className="rounded-[26px] border border-slate-100 bg-white/80 p-5 shadow-[0_10px_28px_rgba(15,23,42,0.05)] transition-shadow hover:shadow-[0_18px_44px_rgba(124,58,237,0.14)]"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-lg font-bold text-slate-950">{item.candidate}</div>
                <div className="text-sm text-slate-500">{item.role}</div>
              </div>
              <motion.span
                animate={item.status === "Live" ? { scale: [1, 1.3, 1] } : {}}
                transition={{ duration: 1.4, repeat: item.status === "Live" ? Infinity : 0, ease: "easeInOut" }}
                className={`inline-flex h-3 w-3 rounded-full ${statusDot(item.status)}`}
              />
            </div>
            <div className="mt-4 flex items-center gap-2 rounded-full bg-violet-50 px-3 py-2 text-xs font-semibold text-violet-700">
              <Clock3 size={13} />
              {item.time}
            </div>
            <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4 text-sm text-slate-500">
              <span>{item.type}</span>
              <motion.button
                whileHover={{ scale: 1.05, x: 2 }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center gap-2 rounded-full bg-violet-600 px-4 py-2 text-xs font-semibold text-white"
              >
                Join Meeting <MoveRight size={13} />
              </motion.button>
            </div>
          </motion.div>
        ))}
      </div>
    </GlassPanel>
  );
}

function DashboardContent({ page }: { page: RecruiterPortalPage }) {
  switch (page) {
     case "home":
      return <HomePage />;
    case "dashboard":
      return <DashboardPage />;
    case "jobs":
      return <JobsPage />;
    case "applications":
      return <ApplicationsPage />;
    case "shortlisted":
      return <ShortlistedPage />;
    case "post-job":
      return <JobFormPage />;
    case "company":
      return <CompanyPage />;
    case "settings":
      return <SettingsPage />;
    case "interviews":
      return <InterviewsPage />;
    default:
      return <DashboardPage />;
  }
}

export default function RecruiterPortal({ page }: RecruiterPortalProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout, user } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    setPortalRole(null);
    await logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#f8f7ff_36%,#ffffff_100%)] overflow-x-hidden">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_top_left,rgba(167,139,250,0.18),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(56,189,248,0.10),transparent_33%)]" />
      <div className="pointer-events-none fixed inset-0 bg-[linear-gradient(rgba(255,255,255,0.08),rgba(255,255,255,0.08))]" />

      <MobileDrawer open={mobileOpen} currentPage={page} onClose={() => setMobileOpen(false)} onNavigate={(path) => navigate(path)} onLogout={handleLogout} />

      <div className="relative min-h-[100vh]">
        <TopNavBar
          currentPage={page}
          onNavigate={(path) => navigate(path)}
          onLogout={handleLogout}
          onOpenMobileMenu={() => setMobileOpen(true)}
          user={user}
        />

        <main className="px-4 py-5 md:px-6 lg:px-8 lg:py-7">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: "easeOut" }}
            >
              <DashboardContent page={page} />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}